#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/home/qbus/hcb/libraries/sysroot-arm/lib"
XML2_LIBS="-lxml2    -lm "
XML2_INCLUDEDIR="-I/home/qbus/hcb/libraries/sysroot-arm/include/libxml2"
MODULE_VERSION="xml2-2.9.2"

