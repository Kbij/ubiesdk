local ob = require "_openssl.ocsp.basic"

return ob
