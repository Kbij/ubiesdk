rocks_trees = {
   { name = [[user]], root = home..[[/.luarocks]] },
   { name = [[system]], root = [[/home/qbus/ubie/libraries/sysroot-x86]] }
}
